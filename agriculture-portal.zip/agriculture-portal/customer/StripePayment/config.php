<?php
	require_once "stripe-php-master/init.php";
	require_once "products.php";

$stripeDetails = array(
		"secretKey" => "sk_test_51OeW9uSAYJsLaztSpVdL5tEnlekZXSYxhzVTp0n8KqLucX169v7uMGiNxWGZhfxxTeJxtDtCDmnV4yFjzm29BJVO00r58pjoT1",  //Your Stripe Secret key
		"publishableKey" => "pk_test_51OeW9uSAYJsLaztSIa50Fp1kAe5QxhOGfJXfynHXcgsFJX0KQ3RuGMiHno45AVpdPyebLLvDHUPgQadxJwFPEVft000NTyY95E"  //Your Stripe Publishable key
	);

	// Set your secret key: remember to change this to your live secret key in production
	// See your keys here: https://dashboard.stripe.com/account/apikeys
	\Stripe\Stripe::setApiKey($stripeDetails['secretKey']);

	
?>
